import smtplib
from email.mime.base import MIMEBase
from email import encoders
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
import getpass
import fbchat
from pyautogui import *
#Button To enter into Teminal mode. 
your_mode= confirm(text='WELCOME!!!!',title='Mode details:Multi Messenger',buttons=['TERMINAL MODE'])
if (your_mode == "TERMINAL MODE"):
            print ("""  ------------------------------------
                        |     WELCOME TO MULTIMESSENGER    |         
                        |                                  |              
                        |     BUILT BY:                    |       
                        |                                  |
                        |             K.GAURAV KUMAR       |
                        |             MANISHA KUMARI       |
                        |             SURAJ KUMAR          |
                        |                                  |
                        |     Undergraduate Students at:   |               
                        |           LOVELY PROFESSIONAL    |
                        |            UNIVERSITY            |        
                        |           (BTECH IT)             |                
                        ------------------------------------
            -------------------------------------------------------------------------""")
            # DETAILS - Email
            print ("-------------------------------------------------------------------------")
            print ("Enter your Email-ID details")
            print ("-------------------------------------------------------------------------")

            your_adr = input("Your email-ID: ")
            pass_adr = getpass.getpass()

            # DETAILS - Facebook Message

            print ("-------------------------------------------------------------------------")
            print ("Enter your Facebook Details")
            print ("-------------------------------------------------------------------------")
            your_id = str(input("Enter your username: "))
            pass_fb = getpass.getpass()

            # DETAILS - SMS 

            print ("-------------------------------------------------------------------------")
            print ("Enter your SMS Details")
            print ("-------------------------------------------------------------------------")

            ACCOUNT_SID = input("Account SID: ") # <auth sid>
            AUTH_TOKEN = input("Account Token: ") # <auth token>
            fromNumber = str(input("Enter your number: "))
            exit_input = input("""If you want to exit, type "EXIT", else Press any key.""")
            while(exit_input != "EXIT"):
                  # MENU
                  print (" EMAIL [1]  |  FACEBOOK MESSAGE [2] |  SMS [3] ")

                  number = int(input("Menu Selection: "))

                  if(number == 1):
                    rec_adr = input("Receiver's email ID: ")

                    msg = MIMEMultipart()

                    subj = input("Subject: ")
                    msg['From'] = your_adr
                    msg['To'] = rec_adr
                    msg['Subject'] = subj

                    body = input("Text you want to enter: ")

                    msg.attach(MIMEText(body, 'plain'))

                    strings = input("Enter file address: ")
                    if(strings != ''):
                          attachment = open(strings, "rb")
                          part = MIMEBase('application', 'octet-stream')
                          part.set_payload((attachment).read())
                          encoders.encode_base64(part)
                          part.add_header('Content-Disposition', "attachment; filename = %s" % strings)
                              
                    msg.attach(part)

                    server = smtplib.SMTP('smtp.gmail.com', 587)
                    server.starttls()
                    server.login(your_adr, pass_adr)
                    text = msg.as_string()
                    server.sendmail(your_adr, rec_adr, text)
                    server.quit()
                    
                  # FB CHAT
                  elif(number == 2):
                    client = fbchat.Client(your_id, pass_fb);
                    print ("Type your friend's name: ")
                    fname = str(input("Enter friend's name: "))
                    friends = client.getUsers(fname)

                    friend = friends[0]
                    messagetosend = str(input("Message to send: "))
                    sent = client.send(friend.uid, messagetosend)
                    if sent:
                        print("Message sent successfully")
                    else:
                        print("Message Sending Failed")
                        
                  # SMS 
                  elif(number == 3):
                    client = TwilioRestClient(ACCOUNT_SID, AUTH_TOKEN)

                    # Input details
                    ToNumber = str(input("Enter the number you want to send SMS: "))
                    bodyText = str(input("Enter text you want to enter: "))
                    client.messages.create(
                        to = '+91' + ToNumber,
                        from_ = '+' + fromNumber , #<fromNumber>
                        body = bodyText,
                    )
                  exit_input = input("""If you want to exit, type "EXIT", else Press any key.""")
